Hello!

For performance, the only score you need to open is SmallMusic.maxpat. All instructions can be found either inside the patcher, or in the PDF output sheet music. PLEASE generate a fresh score and sight read for the performance. This makes a world of difference towards the spirit of the piece. Scores can be generated at:

www.brianellissound.com/smallMusic

thanks,
Brian